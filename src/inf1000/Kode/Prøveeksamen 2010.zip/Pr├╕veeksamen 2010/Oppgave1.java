class Oppgave1{
    public static void main(String[] args) {

        // 1A

        int teller = 0;
        for (int i = 10; i >= 5; i--){
            for (int j = 0; j < 6; j++){
                teller++;
            }
        }

        System.out.println("Oppgave 1a: " + teller);
        teller = 0;


        // 1B

        teller = 0;
        for (int i = 5; i > 0; i--){
            for (int j = 0; j < i; j++){
                teller++;
            }
        }

        System.out.println("Oppgave 1b: " + teller);
        teller = 0;



        // 1C

        teller = 0;
        for (int i = 0; i < 5; i++){
            int k = 5-i;
            while(k > 0){
                teller++;
                k--;
            }
        }

        System.out.println("Oppgave 1c: " + teller);
        teller = 0;


        // 1D

        teller = 0;
        for (int i = 0; i < 10; i += 2){
            for (int k = 3; k > -1; k--){
                k--;
                teller++;
            }
        }

        System.out.println("Oppgave 1d: " + teller);
        teller = 0;


    }
}
