Hei!

I Idrettslag har jeg valgt å dele opp i flere mindre metoder.
I løsningsforslaget gitt ut i 2010 valgte de å løse alt i én metode (Se "2010.pdf").

Si ifra om dere lurer på noe :)

Nicolai
