import java.util.HashMap;

public class Idrettslag{
    private HashMap<String, Medlem> medlemmer;
    public Idrettslag(){
        medlemmer = new HashMap<>();
    }

    public void leggTilMedlem(Medlem medlem){
        medlemmer.put(medlem.toString(), medlem);
    }

    public void slettMedlem(String medlemsnr){
        medlemmer.remove(medlemsnr);
    }

    public Medlem hentMedlem(String medlemsnr){
        return medlemmer.get(medlemsnr);
    }

    public void sok(String tekst){
        for (Medlem medlem : medlemmer.values()){
            if (medlem.hentTlf().equals(tekst) || medlem.hentNavn().equals(tekst)){
                skrivUtOmMedlem(medlem);
            }
        }
    }

    public void registrerBetaling(String medlemsnr){
        Medlem medlem = medlemmer.get(medlemsnr);
        if (medlem==null){
            System.out.println("Medlemmet fantes ikke!");
        } else {
            medlem.registrerBetaling();
        }
    }

    public void skrivUtOmMedlem(Medlem medlem){
        System.out.println("Medlemsnr:" + medlem.hentMedlemsNr() +
        " - Navn:" + medlem.hentNavn() + " - Tlf:" + medlem.hentTlf());
    }

    public void skrivPurreListe(){
        System.out.println("Følgende har ikke betalt:");
        for (Medlem medlem : medlemmer.values()){
            if (!medlem.harBetalt()){
                skrivUtOmMedlem(medlem);
            }
        }
    }

    public void harLikeTlfNr(){
        HashMap<String, String> telefon = new HashMap<>();

        for (Medlem medlem : medlemmer.values()){
            if (hvorMangeHarTlf(medlem.hentTlf()) > 1){
                telefon.put(medlem.hentTlf(), medlem.hentTlf());
            }
        }

        if (telefon.size() == 0){
            System.out.println("Ingen har like telefonnummer!!!");
        } else {
            for (String etNr : telefon.values()){
                printNavnMedTlfNr(etNr);
            }
        }
    }

    public void printNavnMedTlfNr(String tlf){
        for (Medlem medlem : medlemmer.values()){
            if (medlem.hentTlf().equals(tlf)){
                skrivUtOmMedlem(medlem);
            }
        }
    }

    public int hvorMangeHarTlf(String tlf){
        int teller = -1;
        for (Medlem medlem : medlemmer.values()){
            if (medlem.hentTlf().equals(tlf)){
                teller++;
            }
        }
        return teller;
    }

}
