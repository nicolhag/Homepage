class Oppgave5{
    public static void main(String[] args) {
        Oppgave5 o = new Oppgave5();
    }

    double motstand (double spenning, double strom)
    {
        if (strom == 0){
            return -1;
        } else {
            return spenning/strom;
        }
    }

    String delStreng(String tekst, int k){
        if (k > tekst.length()){
            return tekst;
        }
        String toReturn = "";
        for (int i = 0; i < k; i++){
            toReturn += tekst.charAt(i);
        }
        return toReturn;
    }

    String[] fjernForste (String[] array){
        String[] ny = new String[array.length-1];
        for (int i = 1; i < ny.length; i++){
            ny[i-1] = array[i];
        }
        return ny;
    }

    boolean harToLikeTall( int [] tall ){
        for( int i=0; i<tall.length; i++ ){
            for( int j=i+1; j<tall.length; j++ ){
                if( tall[i]==tall[j] ){
                    return true;
                }
            }
        }
        return false;
    }
}
