public class PersonArray{
    private Person[] personliste;
    private int antallPersoner;
    public PersonArray(){
        antallPersoner = 0;
        personliste = new Person[1000];
        settInn(new Person("Ole Olsen", 45003334));
        settInn(new Person("Kari Karlsen"));

        for (int i = 0 ; i < antallPersoner; i++){
            if (!personliste[i].harTlf()){
                System.out.println("Navnet er: " + personliste[i]);
            }
        }
    }

    public void settInn(Person p){
        personliste[antallPersoner++] = p;
    }

    public static void main (String[] args){
        new PersonArray();
    }
}
