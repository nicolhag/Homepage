public class Person{
    private String navn;
    private int tlfnr; // 0 indikerer ingen telefonnummer

    public Person(String navn){
        this.navn = navn;
        this.tlfnr = 0;
    }

    public Person(String navn, int tlfnr){
        this.navn = navn;
        this.tlfnr = tlfnr;
    }

    public boolean harTlf(){
        return (tlfnr != 0);
    }
}
