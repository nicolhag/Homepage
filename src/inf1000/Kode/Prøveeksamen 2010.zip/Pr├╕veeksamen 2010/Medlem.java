public class Medlem{
    private String medlemsnr;
    private String navn;
    private String tlf;
    private boolean kontigentBetalt;
    public Medlem(String medlemsnr, String navn, String tlf){
        this.medlemsnr = medlemsnr;
        this.navn = navn;
        this.tlf = tlf;
        kontigentBetalt = false;
    }

    public String hentNavn(){
        return navn;
    }

    public String hentTlf(){
        return tlf;
    }

    public String hentMedlemsNr(){
        return medlemsnr;
    }

    public void registrerBetaling(){
        kontigentBetalt = true;
    }

    public boolean harBetalt(){
        return kontigentBetalt;
    }
}
