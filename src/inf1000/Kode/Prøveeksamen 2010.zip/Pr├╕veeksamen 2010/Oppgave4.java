class Oppgave4{
    public static void main(String[] args) {
         String[] navn = { "Per", "Per" };
         if (navn[0].equals(navn[1])) {
             navn [0] += navn [1];
             navn [1] += navn [0];
         }
         if (navn[0] == navn[1]){
             System.out.println("Pekerlikhet");
         } else {
             System.out.println("Ikke pekerlikhet");
         }
         if (navn[0].equals(navn[1])) {
             System.out.println("Like");
         } else {
             System.out.println("Ulike");
         }
    }
}
