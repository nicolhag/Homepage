Mappene inneholder et program gjennomgått på seminartimen 2. Oktober.
Programmet er litt større enn det vi hittil er vant til, så det er ikke nødvendig å forstå alt med en gang.
Likevel er alle elementene brukt i programmet ting som er gjennomgått på forelesninger og gruppetimer.
Om du har spørsmål, ta gjerne kontakt på nicolhag@ifi.uio.no

Nicolai
