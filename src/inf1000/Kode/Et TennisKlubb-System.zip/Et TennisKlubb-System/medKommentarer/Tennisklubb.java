public class Tennisklubb{

    // Array som kan holde paa objekter av klassen Trener
    private Trener[] trenere;
    private int antallTrenere;

    // Final-variable vil aldri endres etter at de er satt, og har kun store bokstaver
    private final int MAKS_KAPASITET;

    /*
    Konstruktor til Tennisklubb, hvor man under opprettelse ("new Tennisklubb()")
    trenger aa spesifisere hvor mange trenere tennisklubben har plass tennisklubben.
    Array-storrelsen blir dermed ulike for ulike objekter av klassen Tennisklubb.
    */
    public Tennisklubb(int kapasitet){
        trenere = new Trener[kapasitet];
        antallTrenere = 0;
        MAKS_KAPASITET = kapasitet;
    }

    /*
    Metode for aa finne ut av hvilken trener som skal faa det nye medlemmet.
    Om det ikke er plass til et nytt medlem i tennisklubben, faar bruker
    beskjed om at medlemmet ikke kan legges inn.
    Til metoden faar man en peker til et objekt av klassen Medlem,
    som er opprettet i TestTennisSystem-klassen.
    */
    public void leggTilNyttMedlem(Medlem medlem){

        // Starter med aa si at medlemmet ikke har blitt lagt til
        boolean blittLagtTil = false;

        /*
        Loper gjennom trenere-arrayet for aa finne en trener som kan ta imot
        det nye medlemmet.
        */
        for (int i = 0; i < antallTrenere; i++){
            // Henter ut Trener-objektet paa indeksen (i) man ser paa
            Trener enTrener = trenere[i];

            /*
            Sjekker om treneren man hentet ut har kapasitet ved aa kalle paa
            boolean-metoden _harKapasitet_, som vil returnere true om
            treneren har plass i sitt array av medlemmer,
            og dermed ikke naadd sin maksKapasitet. Her sjekkes det ogsaa om
            medlemmet allerede har blitt lagt til en Trener
            */
            if ( enTrener.harKapasitet() && !blittLagtTil ){
                /*
                Siden if-testen slo til, vet vi naa at vi kan legge til
                medlemmet til Trener-objektet vi hentet ut
                */
                enTrener.leggTilMedlem(medlem);

                // Sier ifra om at medlemmet naa har blitt lagt til.
                blittLagtTil = true;
            }
        }
        /*
        Hvis if-testen over aldri slo til, ble ikke medlemmet lagt til.
        Det er med andre ord ikke plass til dette medlemmet i tennisklubben.
        Printer derfor en forklaring til bruker at medlemmet ikke kunne legges til.
        */
        if (! blittLagtTil){
            System.out.println(medlem.hentNavn() + " kan ikke legges til!");
        }
    }

    /*
    Metode for aa legge til en ny trener, som tar inn et Trener-objekt som
    ble opprettet i TestTennisSystem-klassen.
    Om det ikke er plass til en ny tennistrener i tennisklubben, gis det beskjed til bruker,
    ellers legges treneren inn paa neste ledige plass - og man oppdaterer antallTrenere-variablen
    */

    public void leggTilNyTrener(Trener nyTrener){
        if (antallTrenere == MAKS_KAPASITET){
            System.out.println("Fullt!");
        } else {
            trenere[antallTrenere++] = nyTrener;
        }
    }
}
