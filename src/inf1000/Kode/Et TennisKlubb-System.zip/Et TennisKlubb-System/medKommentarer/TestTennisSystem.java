/*
Klasse for aa teste en opprettelse av en Tennisklubb,
og prove aa legge til trenere og nye medlemmer til klubben.

OPPGAVETEKST:
“Oslo tennisklubb (OTK) onsker aa effektivisere sin bedrift.
Dette kan de gjore ved aa la et datasystem enkelt kunne registrere
nye medlemmer til trenere med ledig kapasitet. ImplementEr dette systemet”
*/

public class TestTennisSystem{
    public static void main(String[] args) {

        /*
        Oppretter en ny tennisklubb, otk (Oslo Tennisklubb),
        med kapasitet til aa ha ansatt 5 trenere
        */
        Tennisklubb otk = new Tennisklubb(5);
        /*
        Oppretter et nytt trenerobjekt, med navn Kaare, som kan
        vaere trener for maks 3 medlemmer
        */
        Trener kaare = new Trener("Kaare", 3);
        Trener thea = new Trener("Thea", 30);
        Medlem nyttMedlem = new Medlem("Nicolai");

        // Setningene sender med Trener-objektene til Tennisklubb-objektet otk
        otk.leggTilNyTrener(kaare);
        otk.leggTilNyTrener(thea);

        // Sender med en peker til et nylig opprettet Medlem-objekt (se linje 20).
        otk.leggTilNyttMedlem(nyttMedlem);

        // Sender med en peker til et nytt Medlem-objekt
        otk.leggTilNyttMedlem(new Medlem("Siri"));
        otk.leggTilNyttMedlem(new Medlem("Geir Kjetil"));
        otk.leggTilNyttMedlem(new Medlem("Henrik"));
    }
}
