public class Medlem{
    private String navn;

    // Konstruktor til klassen medlem
    public Medlem(String navn){
        /*
        "Vi setter dette objektet sin instansvariabel navn
        til a vaere navn som kom inn som parameter til konstruktoren"
        */
        this.navn = navn;
    }

    // En del av grensesnittet til klassen medlem, som returnerer innholdet i instansvariablen
    public String hentNavn(){
        return navn;
    }
}
