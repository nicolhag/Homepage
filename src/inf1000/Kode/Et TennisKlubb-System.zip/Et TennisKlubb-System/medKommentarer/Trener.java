
// Legg merke til at klassen er satt til public, fordi den vaere synlig fra utsiden (fra andre klasser)
public class Trener{

    /*
    Legg her merke til at instansvariablene er satt til _private_ for aa innkapsle dataene
    tilhorende en Trener - kun til aa vaere tilgjengelig fra dette objektet
    */
    private String navn;
    private int kapasitet;
    // Deklarerer en array som kan holde paa objekter av klassen Medlem
    private Medlem[] medlemmer;
    private int antallMedlemmer;

    // Konstruktor for nye objekter av klassen Trener
    public Trener(String navn, int kapasitet){
        this.navn = navn;
        this.kapasitet = kapasitet;
        medlemmer = new Medlem[kapasitet];
        // Legg merke til at variabelen forst initialiseres i konstruktoren
        antallMedlemmer = 0;
    }

    /*
    Metoden faar inn en peker til et objekt av klassen Medlem,
    som allerede er opprettet ved aa si "new Medlem(...)" i TestTennisSystem.
    */
    public void leggTilMedlem(Medlem nyttMedlem){
        /*
        Printer ut navnet paa medlemmet ved aa kalle paa metoden hentNavn,
        som er en del av grensesnittet til objekter av klassen Medlem
        */
        System.out.println("La til medlem: " + nyttMedlem.hentNavn() + " - til treneren " + navn);

        /*
        Setter inn paa neste indeks i arrayet som holder paa Medlem-objekter.
        Her burde man ogsaa printet ut en feilmelding om arrayet er fullt (som i Tennisklubb).
        Setningen under kan ogsaa erstattes av de to setningene:

        medlemmer[antallMedlemmer] = nyttMedlem;
        antallMedlemmer++;
        */
        medlemmer[antallMedlemmer++] = nyttMedlem;
    }

    /*
    En metode som sjekker om Trener-objektet har plass til aa ta imot nye medlemmer.
    Legg her merke til at siden metoden returnerer en _boolean-verdi_, starter navnet med "har..".
    Grunnen til det er at det blir enklere aa forstaa naar vi kaller metoden senere at den skal gi oss
    svaret ja/nei (true/false). En annen syntaks for metodenavn som returnerer boolean er "er..." ;
    f. eks. erFull()
    */

    public boolean harKapasitet(){
        /*
        Setter en boolean variabel til aa vaere resultatet av sjekken paa hoyresiden.
        De to setningene under kan ogsaa erstattes av:

        return (antallMedlemmer < kapasitet)

        , for aa korte ned antall kodelinjer
        */
        boolean kapasitetsTest = (antallMedlemmer < kapasitet);
        return kapasitetsTest;
    }
}
