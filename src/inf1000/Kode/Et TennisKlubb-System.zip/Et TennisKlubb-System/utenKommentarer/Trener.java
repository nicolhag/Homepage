public class Trener{
    private String navn;
    private int kapasitet;
    private Medlem[] medlemmer;
    private int antallMedlemmer;

    public Trener(String navn, int kapasitet){
        this.navn = navn;
        this.kapasitet = kapasitet;
        medlemmer = new Medlem[kapasitet];
        antallMedlemmer = 0;
    }

    public void leggTilMedlem(Medlem nyttMedlem){
        System.out.println("La til medlem: " + nyttMedlem.hentNavn() + " - til treneren " + navn);
        medlemmer[antallMedlemmer++] = nyttMedlem;
    }

    public boolean harKapasitet(){
        boolean kapasitetsTest = (antallMedlemmer < kapasitet);
        return kapasitetsTest;
    }
}
