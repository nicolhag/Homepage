public class Medlem{
    private String navn;
    public Medlem(String navn){
        this.navn = navn;
    }

    public String hentNavn(){
        return navn;
    }
}
