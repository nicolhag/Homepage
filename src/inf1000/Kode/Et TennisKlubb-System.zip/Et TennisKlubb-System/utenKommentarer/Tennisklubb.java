public class Tennisklubb{
    private Trener[] trenere;
    private int antallTrenere;
    private final int MAKS_KAPASITET;

    public Tennisklubb(int kapasitet){
        trenere = new Trener[kapasitet];
        antallTrenere = 0;
        MAKS_KAPASITET = kapasitet;
    }

    public void leggTilNyttMedlem(Medlem medlem){
        boolean blittLagtTil = false;
        for (int i = 0; i < antallTrenere; i++){
            Trener enTrener = trenere[i];

            if ( enTrener.harKapasitet() && !blittLagtTil ){
                enTrener.leggTilMedlem(medlem);
                blittLagtTil = true;
            }
        }
        if (! blittLagtTil){
            System.out.println(medlem.hentNavn() + " kan ikke legges til!");
        }
    }

    public void leggTilNyTrener(Trener nyTrener){
        if (antallTrenere == MAKS_KAPASITET){
            System.out.println("Fullt!");
        } else {
            trenere[antallTrenere++] = nyTrener;
        }
    }
}
