import java.util.HashMap;

public class Trener{
    private String navn;
    private int kapasitet;
    private HashMap<String, Medlem> medlemmer;

    public Trener(String navn, int kapasitet){
        this.navn = navn;
        this.kapasitet = kapasitet;
        medlemmer = new HashMap<String, Medlem>();
    }

    public String toString(){
        return navn;
    }

    public void leggTilMedlem(Medlem nyttMedlem){
        if (medlemmer.size() > kapasitet){
            System.out.println("Fullt!");
        } else {
            System.out.println(nyttMedlem.hentNavn() + " er nå lagt til: " + navn);
            medlemmer.put(nyttMedlem.hentNavn(), nyttMedlem);
        }
    }

    public boolean harKapasitet(){
        return (medlemmer.size() < kapasitet);
    }
}
