import java.util.*;

public class Tennisklubb{
    private HashMap<String, Trener> trenere;
    private final int MAKS_KAPASITET;

    public Tennisklubb(int kapasitet){
        trenere = new HashMap<String, Trener>();
        MAKS_KAPASITET = kapasitet;
    }

    public Trener finnLedigTrener(){
        for (Trener t : trenere.values() ){
            if ( t.harKapasitet() ){
                return t;
            }
        }
        return null;
    }

    public void leggTilNyttMedlem(Medlem medlem){
        Trener hentetUt = finnLedigTrener();
        if (hentetUt == null){
            System.out.println("Ikke plass til " + medlem.hentNavn());
        } else {
            hentetUt.leggTilMedlem(medlem);
        }
    }

    public void leggTilNyTrener(Trener nyTrener){
        if (trenere.size() == MAKS_KAPASITET){
            System.out.println("Fullt!");
        } else {
            trenere.put(nyTrener.toString(), nyTrener);
        }
    }
}
