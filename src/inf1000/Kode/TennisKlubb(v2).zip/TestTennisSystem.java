public class TestTennisSystem{
    public static void main(String[] args) {
        Tennisklubb otk = new Tennisklubb(5);
        Trener kaare = new Trener("Kaare", 3);
        Trener thea = new Trener("Thea", 30);
        Medlem nyttMedlem = new Medlem("Nicolai");

        otk.leggTilNyTrener(kaare);
        otk.leggTilNyTrener(thea);

        otk.leggTilNyttMedlem(nyttMedlem);
        otk.leggTilNyttMedlem(new Medlem("Siri"));
        otk.leggTilNyttMedlem(new Medlem("Geir Kjetil"));
        otk.leggTilNyttMedlem(new Medlem("Henrik"));
    }
}
