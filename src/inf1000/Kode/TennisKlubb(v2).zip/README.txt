For kommentarer, se versjon 1.
