**************Kjøring av programmet**************

1. Pakk ut zip-filen etter nedlastning
2. Åpne SnakeGame.pde for å kjøre og endre på programmet (resten av filene åpnes automatisk).

Hvis du får feilmelding under kjøring er dette mest sannsynlig fordi du har glemt pkt. 1. 

**************Kjente mangler**************

1. Spillet skal egentlig avsluttes når Snake kjører på seg selv (fikses i CollisionHandler.pde)
2. Gammel highscore huskes ikke for hver gang man starter spillet på nytt


Spillet er laget av Nicolai Hagen ved Institutt for Informatikk - UiO. Endre på koden så mye du vil!
Har du spørsmål - ta gjerne kontakt på nicolhag@ifi.uio.no